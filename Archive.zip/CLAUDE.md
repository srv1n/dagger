# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Important Guidelines

**NO EMOJIS**: Never use emojis in any documentation, code, comments, or communication within this repository. Keep all text professional and emoji-free.

## Project Overview

**Dagger** is a Rust library for executing directed acyclic graphs (DAGs) with three main execution paradigms:

1. **DAG Flow**: Static YAML-defined workflows with dependency management
2. **Pub/Sub Agent System**: Event-driven multi-agent communication via channels
3. **Task Agent System**: Structured task orchestration with persistence and retry mechanisms

## Build Commands

### Basic Development
```bash
# Build the entire workspace
cargo build

# Run tests
cargo test

# Check code without building
cargo check

# Format code
cargo fmt

# Run clippy for linting
cargo clippy
```

### Running Examples
```bash
# Navigate to any example directory and run
cd examples/dag_flow
cargo run

# Or run specific examples from root
cargo run --example simple_task

# Run with logging
RUST_LOG=info cargo run
```

### Development Workflow
```bash
# Check all workspace members
cargo check --workspace

# Test with all features
cargo test --all-features

# Build release version
cargo build --release
```

## Architecture Overview

### Core Components

#### DAG Flow Engine (`src/dag_flow/`)
- **Purpose**: Execute predefined workflows from YAML files
- **Key Types**: `DagExecutor`, `Node`, `NodeAction`, `WorkflowSpec`
- **Usage**: Load YAML workflows and execute with dependency management, retries, and timeouts

#### Task Agent System (`src/taskagent/`)
- **Purpose**: Sophisticated task orchestration with persistence
- **Key Types**: `TaskManager`, `TaskAgent`, `Task`, `TaskStatus`
- **Database**: Uses sled embedded database for persistence in `*_db/` directories
- **Features**: Job persistence, task dependencies, agent-specific assignment, retry mechanisms

#### Pub/Sub System (`src/pubsub/`)
- **Purpose**: Event-driven multi-agent communication
- **Key Types**: `PubSubExecutor`, `PubSubAgent`, `Message`
- **Features**: Dynamic channel creation, schema validation, async message routing

### Macro System (`dagger-macros/`)
Provides procedural macros to reduce boilerplate:
- `#[action]`: Converts functions to DAG actions with schema generation
- `#[task_agent]`: Creates task agents from functions
- `#[pubsub_agent]`: Creates pub/sub agents from functions

### Execution Models

#### Static DAG (YAML-based)
```rust
executor.load_yaml_file("pipeline.yaml")?;
executor.execute_dag(WorkflowSpec::Static { name: "workflow" }, &cache, cancel_rx).await?;
```

#### Agent-Driven Flow (Dynamic)
```rust
executor.execute_dag(WorkflowSpec::Agent { task: "analyze" }, &cache, cancel_rx).await?;
```

#### Task Agent System
```rust
let task_manager = TaskManager::new(registry, "task_db")?;
task_manager.start_job(job_id, tasks, None, None)?;
```

## Key Dependencies

- **petgraph**: DAG data structure and algorithms
- **tokio**: Async runtime (use `--features full`)
- **serde/serde_json**: Serialization
- **sled**: Embedded database for persistence
- **async-broadcast**: Multi-producer multi-consumer channels
- **dashmap**: Concurrent hash maps
- **jsonschema**: Schema validation
- **anyhow**: Error handling

## Development Patterns

### Error Handling
- Use `anyhow::Result<()>` for most functions
- Task agents return `Result<serde_json::Value, String>`
- PubSub agents return `anyhow::Result<()>`

### Database Persistence
- Task managers create `*_db/` directories (excluded from git)
- Use `sled::Db` for embedded database needs
- State is automatically persisted and recoverable

### Async Patterns
- All execution is async with tokio
- Use `Arc<RwLock<T>>` for shared state
- Cache uses `DashMap` for concurrent access

### Testing
- Examples serve as integration tests
- Each example has its own `Cargo.toml` and can be run independently
- Database directories are created per example

## Working with Examples

Examples are structured as independent Rust packages demonstrating different aspects:

- **`simple_task/`**: Basic task execution
- **`dag_flow/`**: YAML-based DAG execution with pipeline.yaml
- **`agent_simple/`**: Basic agent setup
- **`deepresearch/`**: Complex multi-agent research workflow
- **`taskmanager_deepsearch/`**: Task manager with search capabilities

Each example can be run with `cargo run` from its directory or `cargo run --bin example_name` from root.

## Code Conventions

### Naming
- Use snake_case for functions and variables
- Use PascalCase for types and traits
- Agent names in macros use descriptive strings

### File Organization
- Core functionality in `src/`
- Examples in `examples/*/src/`
- Macros in separate `dagger-macros/` crate
- Database files in `*_db/` directories (gitignored)

### Schema Definitions
- Input/output schemas as JSON strings in macros
- Use `serde_json::json!` for runtime JSON construction
- Validate schemas with `jsonschema` crate

## Visualization and Debugging

### DOT Graph Generation
```rust
// For DAG execution
let dot_output = executor.serialize_tree_to_dot("dag_name")?;

// For task execution
let dot_graph = task_manager.get_dot_graph(Some("job_id"))?;
```

### Cache Inspection
```rust
let json_output = serialize_cache_to_prettyjson(&cache)?;
println!("Cache contents: {}", json_output);
```

### Logging
Use `tracing` for structured logging:
```rust
use tracing::{info, error, debug};
use tracing_subscriber::FmtSubscriber;

// Set up in main
let subscriber = FmtSubscriber::builder()
    .with_max_level(Level::INFO)
    .finish();
tracing::subscriber::set_global_default(subscriber)?;
```

## Common Gotchas

1. **Database Locks**: sled databases can only be opened by one process at a time
2. **Async Context**: All agent functions must be async and use proper error handling
3. **Schema Validation**: JSON schemas must be valid and match input/output data
4. **Cancellation**: Use `oneshot::Receiver<()>` for proper cancellation handling
5. **Memory Usage**: Cache data persists in memory; use sparingly for large datasets

## Performance Considerations

- Use `DashMap` for concurrent cache access
- Leverage async-broadcast for efficient message passing
- sled database provides good performance for embedded use
- DOT graph generation can be expensive for large execution trees

## Testing Strategy

- Examples serve as integration tests
- Run specific examples to test workflows
- Use `RUST_LOG=debug` for detailed execution tracing
- Check database state by examining `*_db/` directories